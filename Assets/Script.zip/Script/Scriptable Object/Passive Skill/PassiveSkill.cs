﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Skill", menuName = "Passive Skill/Passive Skill")]
public class PassiveSkill : PassiveSkillBase
{

}
